package src;

import static org.junit.Assert.*;

import org.junit.Test;

import impl.StockCheck;

public class StockCheckTest {
	

	@Test
	public void testGetStockMessage() {
		
	}

	@Test
	public void testGetStockList() {
		
	}

	@Test
	public void testGetSelectedStock() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllStock() {
		fail("Not yet implemented");
	}

}
