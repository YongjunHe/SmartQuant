package src;

import static org.junit.Assert.*;

import org.junit.Test;

public class SummaryCheckTest {

	@Test
	public void testGetSummaryMessage() {
		fail("Not yet implemented");
	}

}
