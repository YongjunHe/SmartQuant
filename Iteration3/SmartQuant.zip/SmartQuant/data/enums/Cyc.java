package enums;

public enum Cyc {
	day, week, twoweek, month, threemonths, year
}
