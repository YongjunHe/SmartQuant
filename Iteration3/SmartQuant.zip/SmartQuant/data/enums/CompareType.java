package enums;

public enum CompareType {

}
