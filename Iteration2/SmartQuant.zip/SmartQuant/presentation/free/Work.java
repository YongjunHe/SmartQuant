package free;

public enum Work {
	Courier,Officer,Finance,Manager,Admin,Stock,TransOffice,Driver
}
