package enums;

public enum DataType {
	volume, pb, high, adj_price, low, date, close, open, turnover
}
