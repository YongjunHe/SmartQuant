package enums;

public enum Location {
	sh, sz

}
