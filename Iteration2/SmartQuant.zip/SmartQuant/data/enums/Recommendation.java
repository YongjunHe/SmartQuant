package enums;

public enum Recommendation {
	
	bad, well, excellent

}
