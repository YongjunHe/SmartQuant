package enums;

public enum MarketType { 
//     Shanghai,Shenzhen,
	   hs300
}
