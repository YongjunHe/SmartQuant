package enums;

public enum StockType {
Internet, Motorway, Estate, Software, Traditional_Chinese_Medicine, Car_Machine, Steel
}
