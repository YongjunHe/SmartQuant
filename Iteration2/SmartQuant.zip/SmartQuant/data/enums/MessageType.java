package enums;

public enum MessageType {

}
